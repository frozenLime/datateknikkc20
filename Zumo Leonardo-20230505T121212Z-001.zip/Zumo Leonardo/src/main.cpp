#include <Wire.h>
#include <Zumo32U4.h>

#include <Orientation.h>
#include <Drive.h>
#include <ZumoSerial.h>
#include <Definitions.h>

Zumo32U4ButtonC C;
Zumo32U4ButtonB B;
Orientation orientation;
Drive drive;
ZumoSerial zumo_serial;
Info zumo_info;


bool debounce(bool pressed) {
  static uint16_t button_state = 0;
  button_state = (button_state<<1) | pressed | 0xfe00;
  return (button_state == 0xff00);
}

void handle_button(){
  if (debounce(C.isPressed())) {
    Serial.println("Button C pressed, calibrating compass with latest info available");
    orientation.calibrate_compass(zumo_info.calibrate);
  }

  if (debounce(B.isPressed())) {
    Serial.println("Button B pressed, calibrating gyro"); // burde sende tilbake til esp-en
    orientation.calibrate_gyro();
    // drive.reset(zumo_info.state.distance);
  }
}

void setup() {
  delay(500);
  Wire.begin();
  Serial.begin(9600);
  zumo_serial.begin(9600);
  orientation.begin();

  zumo_info = zumo_serial.read(zumo_info);
  orientation.calibrate_compass(zumo_info.calibrate);
}
 
void loop() {
  handle_button();
  orientation.update_angle();
  drive.update(zumo_info.state.angle, orientation.measured_angle);

  zumo_info = zumo_serial.read(zumo_info);
  if(zumo_serial.received_message) {
    Serial.println("received");
    drive.reset(zumo_info.state.distance);
  }

  // Serial.println(zumo_info.calibrate.label);
  // Serial.println(zumo_info.calibrate.offset);
  // Serial.println(zumo_info.calibrate.factor);

  delay(frame);
}