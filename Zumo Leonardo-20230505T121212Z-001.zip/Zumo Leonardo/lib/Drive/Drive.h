#ifndef Drive_h
#define Drive_h

#include <Arduino.h>
#include <Zumo32U4Motors.h>
#include <Zumo32U4Encoders.h>

class Drive {
    public:
        Drive();
        void update(float angle, float measured_angle);
        float get_speed();
        void reset(int distance);
    private:
        float _speed = 0;
        float _angle;
        float _measured_angle;
        int _offset = 1;
        int _rotational_speed;
        int _distance_to_drive;
        int _driven_distance = 0;
        int _target_speed;

        const float _acceleration = 300;
        const int _max_rotational_speed = 100;
        const int _angle_sensitivity = 10;

        Zumo32U4Encoders _encoder;
        Zumo32U4Motors _motors;
};

#endif