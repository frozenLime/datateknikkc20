#include <Arduino.h>
#include <Drive.h>

#include <Zumo32U4Motors.h>
#include <Zumo32U4Encoders.h>

Drive::Drive(){
    _encoder.getCountsAndResetLeft();
    _encoder.getCountsAndResetRight();
}

void Drive::reset(int distance){
    _distance_to_drive = distance;
    _driven_distance = 0;
    _encoder.getCountsAndResetLeft();
    _encoder.getCountsAndResetRight();
}

void Drive::update(float angle, float measured_angle){
    // Figure out how much time has passed since the last update.
    static uint16_t lastUpdate = 0;
    uint16_t m = micros();
    uint16_t dt = m - lastUpdate;
    lastUpdate = m;

    if (_driven_distance < _distance_to_drive){
        _target_speed = 200;
    } else {
        _target_speed = 0;
    }

    _angle = angle;
    _measured_angle = measured_angle;
    _driven_distance = (_encoder.getCountsLeft() + _encoder.getCountsRight()) / 909.7 * 39 * PI;
    Serial.println(_driven_distance);

    if((int)_speed < (int)(_target_speed - _acceleration * dt / 1000000)) {
        _speed += _acceleration * dt / 1000000;
    } else if(_speed > _target_speed + _acceleration * dt / 1000000) {
        _speed -= _acceleration * dt / 1000000;
    } else {
        _speed = _target_speed;
    }

    if(abs(_angle - _measured_angle) < _angle_sensitivity){
        _rotational_speed = (_angle - _measured_angle) / _angle_sensitivity * _max_rotational_speed; // up to 10 degree angle it will speed up correction to max correction
    } else if(_measured_angle < _angle){
        _rotational_speed = _max_rotational_speed;
    } else if(_measured_angle > _angle){
        _rotational_speed = -_max_rotational_speed;
    }

    _motors.setSpeeds(_speed + _rotational_speed, _speed - _rotational_speed);
}

float Drive::get_speed(){
    return _speed;
}
