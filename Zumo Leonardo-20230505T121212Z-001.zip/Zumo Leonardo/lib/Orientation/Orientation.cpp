#include <Arduino.h>
#include <Orientation.h>

#include <Zumo32U4IMU.h>
#include <Definitions.h>

Orientation::Orientation(){

}

bool Orientation::begin(){
  calibrate_gyro();
}

bool Orientation::calibrate_gyro(){
  delay(500);

  measured_angle = 0;
  if (!_imu.init()){
    return(0);
  }
  
  _imu.enableDefault();
  _imu.configureForTurnSensing();


  for(int i = 0; i<1024; i++) { // kalibrering mens den står stille, tar gjennomsnitt
    _imu.readGyro();
    _gyro_offset.z += _imu.g.z;
  }
  _gyro_offset.z /= 1024;
  _gyro_offset.calibrated = true;

  update_angle();
  float before_angle = measured_angle;
  Serial.print("before angle ");
  Serial.println(before_angle);
  float before_time = millis();
  while(millis() - before_time < 5000){
    update_angle();
    delay(frame);
  }

  float after_angle = measured_angle;
  Serial.print("after angle ");
  Serial.println(after_angle);

  Serial.print("delta angle ");
  _gyro_offset.angular_speed_offset += (double)(before_angle - after_angle) * 1000 / (double)(millis()-before_time);
  Serial.println(_gyro_offset.angular_speed_offset);


  return(1);
}

bool Orientation::calibrate_compass(Calibrate calibrate){
  _calibrate = calibrate;

  measured_angle += _calibrate.offset;
  _compass_calibrated = true;
}

bool Orientation::update_angle(){
    if(_gyro_offset.calibrated == true) {
        // Figure out how much time has passed since the last update.
        static uint16_t lastUpdate = 0;
        uint16_t m = micros();
        uint16_t dt = m - lastUpdate;
        float gyroAngularSpeed = 0;
        lastUpdate = m;

        _imu.readGyro();
        // Obtain the angular speed out of the gyro. The gyro's 
        // sensitivity is 0.07 dps per digit.
        gyroAngularSpeed = ((float)_gyro_offset.z - (float)_imu.g.z) * 0.07 * 3.1416;

        // Calculate how much the angle has changed, in degrees, and
        // add it to our estimation of the current angle.
        measured_angle += (gyroAngularSpeed * dt / 1000000) * _calibrate.factor;
        return(1);
    }
    return(0);
}