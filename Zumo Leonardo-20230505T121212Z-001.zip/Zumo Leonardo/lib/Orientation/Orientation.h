#ifndef Orientation_h
#define Orientation_h

#include <Arduino.h>
#include <Zumo32U4IMU.h>
#include <Definitions.h>

class Orientation {
    public:
        Orientation();
        bool begin();
        bool update_angle();
        bool calibrate_compass(Calibrate calibrate);
        bool calibrate_gyro();
        float measured_angle;
    private:
        Zumo32U4IMU _imu;
        struct {
            float z;
            bool calibrated = false;
            float angular_speed_offset = 0;
        } _gyro_offset;
        Calibrate _calibrate;
        bool _compass_calibrated = false;
};

#endif