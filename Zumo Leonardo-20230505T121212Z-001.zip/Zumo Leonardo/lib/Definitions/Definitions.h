#ifndef Definitions_h
#define Definitions_h

const int frame = 100;

struct __attribute__((__packed__)) Message {
    char label;
    float num_1;
    float num_2;
};

struct __attribute__((__packed__)) State {
    char label = 's';
    float angle;
    float distance;
};

struct __attribute__((__packed__)) Calibrate {
    char label = 'c';
    float offset = 0;
    float factor = 1;
};

struct Info {
    State state;
    Calibrate calibrate;
};

#endif