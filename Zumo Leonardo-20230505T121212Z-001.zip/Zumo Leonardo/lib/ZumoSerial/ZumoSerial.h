#ifndef ZumoSerial_h
#define ZumoSerial_h

#include <Arduino.h>
#include <Definitions.h>

class ZumoSerial {
    private:
        Message _message;
    public:
        bool received_message = false;
        ZumoSerial();
        void begin(int baud_rate);
        Info read(Info zumo_info);
};

#endif