#include <ZumoSerial.h>
#include <Arduino.h>
#include <Definitions.h>

ZumoSerial::ZumoSerial(){

}

void ZumoSerial::begin(int baud_rate) {
  Serial1.begin(baud_rate);
}

Info ZumoSerial::read(Info zumo_info){
  char received_byte;
  byte incoming_bytes[sizeof(_message)];
  bool reading = false;
  static int i = 0;

  received_message = false;
  if (Serial1.available() >= sizeof(_message) + 2) {
    received_message = true;
    while (Serial1.available() > 0) {
      received_byte = Serial1.read();

      if (received_byte == '\r') {
        reading = true;
        i = 0;
      } else if (received_byte == '\n') {
        reading = false;
      } else if (reading) {
        incoming_bytes[i] = received_byte;
        i++;
      }
    }
  }

  if(sizeof(incoming_bytes) == sizeof(_message)) {
    memcpy(&_message, incoming_bytes, sizeof(_message));
  }

  switch(_message.label){
    case 's':
      zumo_info.state.angle = _message.num_1;
      zumo_info.state.distance = _message.num_2;
      break;
    case 'c':
      zumo_info.calibrate.offset = _message.num_1;
      zumo_info.calibrate.factor = _message.num_2;  
      break;    
  }

  return zumo_info;
}
